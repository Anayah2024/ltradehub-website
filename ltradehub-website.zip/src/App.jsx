import { motion } from "framer-motion";
import { Globe, Package, Phone, MessageCircle } from "lucide-react";

export default function App() {

  const whatsappNumber = "0689968472";
  const whatsappLink = `https://wa.me/27${whatsappNumber.substring(1)}`;

  const categories = [
    "Electronics & Gadgets",
    "Home Appliances",
    "Industrial Equipment",
    "Fashion & Clothing",
    "Auto Parts",
    "Construction Materials",
    "Office Supplies",
    "Global Sourcing Requests"
  ];

  return (
    <div className="min-h-screen bg-gray-50">

      <section className="bg-black text-white text-center py-20 px-4">
        <motion.h1 className="text-4xl font-bold">
          L Trade Hub
        </motion.h1>

        <p className="mt-3 text-lg">
          Connecting Global Products to South Africa
        </p>

        <div className="mt-6 flex justify-center gap-4 flex-wrap">

          <a href={whatsappLink} target="_blank"
            className="bg-green-500 px-6 py-3 rounded-full flex items-center gap-2">
            <MessageCircle size={18}/> WhatsApp
          </a>

          <a href="tel:0689968472"
            className="bg-white text-black px-6 py-3 rounded-full flex items-center gap-2">
            <Phone size={18}/> Call
          </a>

        </div>
      </section>

      <section className="p-10 text-center">
        <Globe className="mx-auto mb-4" />
        <h2 className="text-2xl font-bold">About Us</h2>
        <p className="mt-3 max-w-2xl mx-auto">
          We source and connect products globally, helping clients in South Africa access reliable suppliers and international goods.
        </p>
      </section>

      <section className="p-10 bg-white">
        <h2 className="text-2xl font-bold text-center mb-6">Categories</h2>

        <div className="grid md:grid-cols-2 gap-4 max-w-5xl mx-auto">
          {categories.map((c,i)=>(
            <div key={i} className="flex items-center gap-3 bg-gray-100 p-4 rounded-xl">
              <Package />
              {c}
            </div>
          ))}
        </div>
      </section>

      <footer className="text-center p-5 bg-black text-white">
        © {new Date().getFullYear()} L Trade Hub
      </footer>

    </div>
  );
}
